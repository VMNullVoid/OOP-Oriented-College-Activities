package com.company;

public class Disciplinas {
    public Disciplinas(String nD, int cargaHoraria, int idDisciplina){
        this.nome = nD;
        this.cargaHoraria = cargaHoraria;
        this.dDisponibilidade = 1;
        this.idDisciplina = idDisciplina;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    private String nome;
    public int getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }
    private int cargaHoraria;

    public int getIdDisciplina() {
        return idDisciplina;
    }

    public void setIdDisciplina(int idDisciplina) {
        this.idDisciplina = idDisciplina;
    }

    private int idDisciplina;

    public int getdDisponibilidade() {
        return dDisponibilidade;
    }

    public void setdDisponibilidade(int dDisponibilidade) {
        this.dDisponibilidade = dDisponibilidade;
    }

    private int dDisponibilidade; //1 para disponivel, 0 para indisponivel

    public NotaDisciplina getNota() {
        return nota;
    }

    public void setNota(NotaDisciplina nota) {
        this.nota = nota;
    }

    private NotaDisciplina nota;
    public void Disciplina(String nD, int cargaHoraria, NotaDisciplina nota, int idDisciplina){
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.dDisponibilidade = 1;
        this.nota = nota;
        this.idDisciplina = idDisciplina;
        //disciplina = new ArrayList<>();
    }
}
