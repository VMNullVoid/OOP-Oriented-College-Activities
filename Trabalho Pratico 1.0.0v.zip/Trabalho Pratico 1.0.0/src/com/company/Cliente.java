package com.company;

public class Cliente {
    private String nome;
    private int cpf;
    private String endereco;
    private int id = 0000;
    private int contador = 1;
    public Cliente(String nome,int cpf, String endereco){
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        id += contador;
        contador++;
    }
    public int getId() {
        return id;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }
}
