package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Aluno {
    public  String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    private String nome;

    public int getAtividade() {
        return atividade;
    }

    public void setAtividade(int atividade) {
        this.atividade = atividade;
    }

    private int atividade; //1 para ativo, 0 para inativo

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    private int idade;

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    private int matricula;

    /*public ArrayList<NotaDisciplina> getNotaDisciplinaAluno() {
        return notaDisciplinaAluno;
    }

    public void setNotaDisciplinaAluno(ArrayList<NotaDisciplina> notaDisciplinaAluno) {
        this.notaDisciplinaAluno = notaDisciplinaAluno;
    }

    private ArrayList<NotaDisciplina>notaDisciplinaAluno;*/
    public Aluno(String nome,int atividade, int idade, int matricula){
        this.nome = nome;
        this.atividade = 1;
        this.idade = idade;
        this.matricula = matricula; //precisamos mudar pra implementar a função de auto incremento
        Main.notaDisciplinaAluno = new ArrayList<>();
    }
}
