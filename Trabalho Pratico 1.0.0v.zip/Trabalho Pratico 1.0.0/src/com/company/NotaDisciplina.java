package com.company;

public class NotaDisciplina {

    public Double getNota() {
        return nota;
    }

    public void setNota(Double nota) {
        if(nota >= 0.0 && nota <= 100.0){
            this.nota = nota;
        }
    }
    private Double nota;

    public Disciplinas getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(Disciplinas disciplina) {
        this.disciplina = disciplina;
    }

    private Disciplinas disciplina;

    public NotaDisciplina(Double nota, Disciplinas disciplina){
        this.nota = nota;
        this.disciplina = disciplina;
    }
}
