package com.company;

public class Conta {
    private String nomeTitular;
    private int cpfTitular;
    private double saldo;

    public Conta(String nomeTitular, int cpfTitular){
        this.nomeTitular = nomeTitular;
        this.cpfTitular = cpfTitular;
    }

    public String getNomeTitular() {
        return nomeTitular;
    }

    public void setNomeTitular(String nomeTitular) {
        this.nomeTitular = nomeTitular;
    }

    public int getCpfTitular() {
        return cpfTitular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo += saldo;
    }
}
