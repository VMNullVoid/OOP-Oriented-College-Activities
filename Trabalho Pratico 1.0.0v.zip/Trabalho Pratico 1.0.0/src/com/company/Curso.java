package com.company;

import java.util.ArrayList;

public class Curso {
    public String getNomeCurso() {
        return nomeCurso;
    }

    public void setNomeCurso(String nomeCurso) {
        this.nomeCurso = nomeCurso;
    }

    private String nomeCurso;

    public int getTurno() {
        return turno;
    }

    public void setTurno(int turno) {
        this.turno = turno;
    }

    private int turno;// 1 para manhã, 2 para tarde, 3 para noite

    public int getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(int idCurso) {
        this.idCurso = idCurso;
    }

    private int idCurso; // 1 para SI, 2 para CC e 3 para ADS

    public ArrayList<Aluno> getAlunosCurso() {
        return alunosCurso;
    }

    public void setAlunosCurso(ArrayList<Aluno> alunosCurso) {
        this.alunosCurso = alunosCurso;
    }
    private ArrayList<Aluno>alunosCurso;

    public int getcDisponibilidade() {
        return cDisponibilidade;
    }

    public void setcDisponibilidade(int cDisponibilidade) {
        this.cDisponibilidade = cDisponibilidade;
    }

    private int cDisponibilidade; //1 para disponivel, 0 para indisponivel
    public Curso(String nomeCurso, int turno, int idCurso){
        this.nomeCurso = nomeCurso;
        this.turno = turno;
        this.idCurso = idCurso;
        this.cDisponibilidade = 1;
        alunosCurso = new ArrayList<>();
    }
}
