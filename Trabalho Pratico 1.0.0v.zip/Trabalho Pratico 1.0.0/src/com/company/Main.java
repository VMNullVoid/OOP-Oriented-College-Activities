package com.company;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static ArrayList<Cliente>clientes = new ArrayList<>();
    static ArrayList<Conta>conta = new ArrayList<>();
    public static ArrayList<NotaDisciplina>notaDisciplinaAluno;
    public static  ArrayList<Aluno>alunosCurso;
    public static ArrayList<Disciplinas> disciplina;
    public static ArrayList<Curso>curso;

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        System.out.println("|----------------------------------|");
        System.out.println("|Qual sistema deseja selecionar?   |");
        System.out.println("|1) Sistema de Alunos da Faculdade |");
        System.out.println("|2) Sistema de contas bancárias    |");
        System.out.println("|3) Sair                           |");
        System.out.println("|----------------------------------|");
        int valor = LerValorInt();
        if(valor == 1){
            MenuFacul();
        } else if(valor == 2){
            MenuBanco();
        } else if(valor == 3){
            System.out.println("Até breve.");
        }else{
            System.out.println("Escolha uma opção válida.");
        }
    }
    public static int LerValorInt(){
        Scanner valor = new Scanner(System.in);
        return valor.nextInt();
        //caso a gente precise usar tá aqui
    }
    public static String LerValorString(){
        Scanner valor = new Scanner(System.in);
        return valor.nextLine();
        //caso a gente precise usar tá aqui
    }
    public static void MenuFacul(){
        ArrayList<NotaDisciplina> notaDisciplinaAluno = new ArrayList<>();
        ArrayList<Disciplinas>disciplinas = new ArrayList<>();
        ArrayList<Aluno> alunosCurso = new ArrayList<>();
        Scanner lerF = new Scanner(System.in);
        System.out.println("|----------------------------------|");
        System.out.println("|O que deseja fazer?               |");
        System.out.println("|1) Gerenciar disciplinas          |");
        System.out.println("|2) Gerenciar cursos               |");
        System.out.println("|3) Gerenciar alunos               |");
        System.out.println("|4) Sair                           |");
        System.out.println("|----------------------------------|");
        int valor = LerValorInt();
        if(valor == 1){
            GerDisciplinas(disciplinas);
        } else if(valor == 2){
            GerCursos(alunosCurso);
        } else if(valor == 3){
       GerAlunos(notaDisciplinaAluno);
        }else if(valor == 4){
            System.out.println("Até breve.");
        }else{
            System.out.println("Escolha uma opção válida.");
        }

    }
    public static void MenuBanco(){
        Scanner lerB = new Scanner(System.in);
        System.out.println("|----------------------------------|");
        System.out.println("|O que deseja fazer?               |");
        System.out.println("|1) Gerenciar Clientes             |");
        System.out.println("|2) Gerenciar Contas               |");
        System.out.println("|3) Sair                           |");
        System.out.println("|----------------------------------|");
        int valor = LerValorInt();
        if(valor == 1){
            GerClientes();
        } else if(valor == 2){
            GerContas();
        } else if(valor == 3){
            System.out.println("Até breve.");
        }else{
            System.out.println("Escolha uma opção válida.");
        }
    }
    public static void CadastrarAluno(ArrayList<Aluno>alunosCurso){
        String n;
        int at;
        int i;
        int m;
        System.out.println("Digite o nome do aluno");
        n = LerValorString();
        System.out.println("Digite o nome do aluno");
        at = LerValorInt();
        System.out.println("Digite o nome do aluno");
        i = LerValorInt();
        System.out.println("Digite o nome do aluno");
        m = LerValorInt();

        Aluno a = new Aluno(n, at, i, m);
        alunosCurso.add(a);
    }
    public static void ConsultarAluno(ArrayList<Aluno>alunosCurso){
        int cGetAluno;
        System.out.println("digite a matrícula do aluno desejado");
        Scanner tGetAluno = new Scanner(System.in);
        cGetAluno = tGetAluno.nextInt();
        for (Aluno a: alunosCurso) {
            if (a.getMatricula() == cGetAluno){
                System.out.println(a.getNome());
                System.out.println(a.getAtividade());
                System.out.println(a.getIdade());
                System.out.println(a.getMatricula());
            }
        }
    }
    public static void ApagarAluno(ArrayList<Aluno>alunosCurso){
        int cGetAluno;
        System.out.println("digite a matrícula do aluno desejado");
        Scanner tGetAluno = new Scanner(System.in);
        cGetAluno = tGetAluno.nextInt();
        for (Aluno a :alunosCurso) {
            if (a.getMatricula() == cGetAluno){
                a.setAtividade(0);
            }
        }
    }
    public static void AtualizarAluno(ArrayList<Aluno>alunosCurso) {
        int cGetAluno;
        System.out.println("digite a matrícula do aluno desejado");
        Scanner tGetAluno = new Scanner(System.in);
        cGetAluno = tGetAluno.nextInt();
        for (Aluno a :alunosCurso) {
            if (a.getMatricula() == cGetAluno) {
                //decidimos por ser possível  mudar apenas o campo idade
                int lIdade;
                System.out.println("Digite o valor a ser atualizado para os campos Atividade e idade, respectivamente. Em atividade digitar '1' para ativo e '2' para inativo");
                Scanner idade = new Scanner(System.in);
                lIdade = idade.nextInt();
                a.setIdade(lIdade);
            }
        }
    }
    public static void CadastrarCurso(ArrayList<Curso>curso){
        String nC;
        int t;
        int idC;
        System.out.println("Digite o nome do Curso");
        nC = LerValorString();
        System.out.println("Digite o turno, 1 para manhã, 2 para tarde, 3 para noite");
        t = LerValorInt();
        System.out.println("Digite o ID do curso, 1 para SI, 2 para CC, 3 para ADS");
        idC = LerValorInt();
        Curso c = new Curso(nC, t, idC);
        curso.add(c);
    }
    public static void ConsultarCurso(ArrayList<Curso>curso){
        int cGetCurso;
        System.out.println("Digite o nome do curso: SI ou CC");
        Scanner tGetCurso = new Scanner(System.in);
        cGetCurso = tGetCurso.nextInt();
        for (Curso c: curso) {
            if (c.getIdCurso() == cGetCurso){
                System.out.println(c.getNomeCurso());
                System.out.println(c.getTurno());
                System.out.println(c.getIdCurso());
                System.out.println(c.getAlunosCurso());
            }
        }
    }
    public static void ApagarCurso(ArrayList<Curso>curso){
        int cGetCurso;
        System.out.println("Digite a matrícula do Curso que deseja apagar");
        Scanner tGetCurso = new Scanner(System.in);
        cGetCurso = tGetCurso.nextInt();
        for (Curso c :curso) {
            if (c.getIdCurso() == cGetCurso){
                c.setcDisponibilidade(0);
            }
        }
    }
    public static void AtualizarCurso(ArrayList<Curso>curso){
        int cGetCurso;
        System.out.println("Digite o ID do Curso desejado");
        Scanner tGetCurso = new Scanner(System.in);
        cGetCurso = tGetCurso.nextInt();
        for (Curso c :curso) {
            if (c.getIdCurso() == cGetCurso) {
                int aTurno;
                System.out.println("Digite o valor a ser atualizado para os campos Atividade e idade, respectivamente. Em atividade digitar '1' para ativo e '2' para inativo");
                Scanner turno = new Scanner(System.in);
                aTurno = turno.nextInt();
                c.setTurno(aTurno);
            }
        }
    }
    public static void CriarDisciplina(ArrayList<Disciplinas>disciplina){
        String nD;
        int cH;
        int n;
        System.out.println("Digite o nome da Disciplina");
        nD = LerValorString();
        System.out.println("Digite o turno, 1 para manhã, 2 para tarde, 3 para noite");
        cH = LerValorInt();
        System.out.println("Digite o ID do curso, 1 para SI, 2 para CC, 3 para ADS");
        n = LerValorInt();
        Disciplinas d = new Disciplinas(nD, cH, n);
        disciplina.add(d);
    }
    public static void ConsultarDisciplina(ArrayList<Disciplinas>disciplina){
        int cGetDisciplina;
        System.out.println("Digite o nome do curso: SI ou CC");
        Scanner tGetDisciplina = new Scanner(System.in);
        cGetDisciplina = tGetDisciplina.nextInt();
        for (Disciplinas d: disciplina) {
            if (d.getIdDisciplina() == cGetDisciplina){
                System.out.println(d.getNome());
                System.out.println(d.getCargaHoraria());
                System.out.println(d.getdDisponibilidade());
                System.out.println(d.getIdDisciplina());
            }
        }
    }
    public static void ApagarDisciplina(ArrayList<Disciplinas>disciplinas){
        int cGetDisciplina;
        System.out.println("Digite o ID da disciplina que deseja apagar");
        Scanner tGetDisciplina = new Scanner(System.in);
        cGetDisciplina = tGetDisciplina.nextInt();
        for (Disciplinas d :disciplina) {
            if (d.getIdDisciplina() == cGetDisciplina){
                d.setdDisponibilidade(0);
            }
        }
    }

    public static void AtualizarDisciplina(ArrayList<Disciplinas>disciplina){
        int cGetDisciplina;
        System.out.println("Digite o ID da Disciplina desejada");
        Scanner tGetDisciplina = new Scanner(System.in);
        cGetDisciplina = tGetDisciplina.nextInt();
        for (Curso c :curso) {
            if (c.getIdCurso() == cGetDisciplina) {
                int aCH;
                System.out.println("Digite o valor a ser atualizado para os campos Atividade e idade, respectivamente. Em atividade digitar '1' para ativo e '2' para inativo");
                Scanner turno = new Scanner(System.in);
                aCH = turno.nextInt();
                c.setTurno(aCH);
            }
        }
    }

    public static void GerAlunos(ArrayList<NotaDisciplina> notaDisciplinaAluno){
        Scanner ler1 = new Scanner(System.in);
        System.out.println("|----------------------------------|");
        System.out.println("|Qual opção deseja selecionar?     |");
        System.out.println("|1) Cadastrar aluno                |");
        System.out.println("|2) Consultar aluno                |");
        System.out.println("|3) Remover  aluno                 |");
        System.out.println("|4) Atualizar aluno                |");
        System.out.println("|5) Voltar ao menu inicial         |");
        System.out.println("|----------------------------------|");
        int valor = LerValorInt();
        switch(valor){
            case 1:
                CadastrarAluno(alunosCurso);
                break;
            case 2:
                ConsultarAluno(alunosCurso);
                break;
            case 3:
                ApagarAluno(alunosCurso);
                break;
            case 4:
                AtualizarAluno(alunosCurso);
                break;
            case 5:
                break;
            default:
            System.out.println("Insira uma opção válida. ");
                break;
        }
    }
    public static void GerDisciplinas(ArrayList<Disciplinas> disciplinas){
        Scanner ler2 = new Scanner(System.in);
        System.out.println("|----------------------------------|");
        System.out.println("|Qual opção deseja selecionar?     |");
        System.out.println("|1) Cadastrar disciplina           |");
        System.out.println("|2) Consultar disciplina           |");
        System.out.println("|3) Remover  disciplina            |");
        System.out.println("|4) Atualizar disciplina           |");
        System.out.println("|5) Voltar ao menu inicial         |");
        System.out.println("|----------------------------------|");
        int valor = LerValorInt();
        switch(valor){
            case 1:
                CriarDisciplina(disciplina);
                break;
            case 2:
                ConsultarDisciplina(disciplina);
                break;
            case 3:
                ApagarDisciplina(disciplina);
                break;
            case 4:
                AtualizarDisciplina(disciplina);
                break;
            case 5:

                break;
            default:
                 System.out.println("Operação inválida.");
                break;
        }
    }
    public static void GerCursos(ArrayList<Aluno> alunosCurso){

        System.out.println("|----------------------------------|");
        System.out.println("|Qual opção deseja selecionar?     |");
        System.out.println("|1) Cadastrar curso                |");
        System.out.println("|2) Consultar curso                |");
        System.out.println("|3) Remover  curso                 |");
        System.out.println("|4) Atualizar curso                |");
        System.out.println("|5) Voltar ao menu inicial         |");
        System.out.println("|----------------------------------|");
        int valor = LerValorInt();
        switch(valor){
            case 1:
                CadastrarCurso(curso);
                break;
            case 2:
                ConsultarCurso(curso);
                break;
            case 3:
                ApagarCurso(curso);
                break;
            case 4:
                AtualizarCurso(curso);
                break;
            case 5:

                break;
            default:
                System.out.println("Operação inválida.");
                break;
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    public static void CadastrarCliente(){
     System.out.println("Digite o nome do Cliente: ");
     String name = LerValorString();
        System.out.println("Digite o CPF do Cliente: ");
        int cepef = LerValorInt();
        System.out.println("Digite o Endereço do Cliente: ");
        String adress  = LerValorString();
        Cliente buddy = new Cliente(name,cepef,adress);
        clientes.add(buddy);
    }
    public static void ConsultarCliente(){
        System.out.println("Digite o CPF do Cliente: ");
        int dado = LerValorInt();
        //Não estou conseguindo trabalhar com atributos privados em expressão lambda
        Cliente ente = clientes.stream().filter(c -> c.getCpf() ==dado).findFirst().orElse(null);
        if (ente != null) {
            //PrintCarro(ente);
        } else {
            System.out.println("Carro não existe");
        }
    }
    public static void RemoverCliente(){
        System.out.println("Digite o CPF do Cliente: ");
        int cepef = LerValorInt();
        //Não estou conseguindo trabalhar com atributos privados em expressão lambda
        Cliente ente = clientes.stream().filter(c -> c.getCpf() ==cepef).findFirst().orElse(null);
        if (ente != null) {
            clientes.remove(ente);
        } else {
            System.out.println("Cliente inexistente.");
        }
    }
    public static void AtualizarCliente(){
        System.out.println("Digite o nome do Cliente: ");
        String name = LerValorString();
        System.out.println("Digite o CPF do Cliente: ");
        int cepef = LerValorInt();
        System.out.println("Digite o Endereço do Cliente: ");
        String adress  = LerValorString();
        Cliente buddy = new Cliente(name,cepef,adress);
        Cliente ente = clientes.stream().filter(c -> c.getCpf() ==cepef).findFirst().orElse(null);

        if (ente != null) {
            buddy.setNome(name);
            buddy.setEndereco(adress);
        } else {
            System.out.println("Cliente inexistente.");
        }
    }
    public static void GerClientes(){
            Scanner ler4 = new Scanner(System.in);
            System.out.println("|----------------------------------|");
            System.out.println("|Qual opção deseja selecionar?     |");
            System.out.println("|1) Cadastrar cliente              |");
            System.out.println("|2) Consultar cliente              |");
            System.out.println("|3) Remover  cliente               |");
            System.out.println("|4) Atualizar cliente              |");
            System.out.println("|5) Voltar ao menu inicial         |");
            System.out.println("|----------------------------------|");
            int valor = LerValorInt();
            switch (valor) {
                case 1:
                    CadastrarCliente();
                    break;
                case 2:
                    ConsultarCliente();
                    break;
                case 3:
                    RemoverCliente();
                    break;
                case 4:
                    AtualizarCliente();
                    break;
                case 5:

                    break;
                default:
                    System.out.println("Operação inválida.");
                    break;
            }
    }
    public static void CriarConta(){
        System.out.println("Digite o nome do Titular: ");
        String name = LerValorString();
        System.out.println("Digite o CPF do Titular: ");
        int cepef = LerValorInt();
        Conta buddy = new Conta(name,cepef);
        conta.add(buddy);
    }
    public static void SacarValor(){
        System.out.println("Digite o CPF do Titular: ");
        int cepef = LerValorInt();
        Conta onta = conta.stream().filter(c -> c.getCpfTitular() ==cepef).findFirst().orElse(null);
        if (onta != null) {
            System.out.println("Digite o valor a ser sacado: ");
           double dinheiro = LerValorInt();
           dinheiro *= -1;
           onta.setSaldo(dinheiro);
        } else {
            System.out.println("Operação inválida, saldo insuficiente.");
            System.out.println("Saldo atual: " + onta.getSaldo());
        }
    }
    public static void DepositarValor(){
        System.out.println("Digite o CPF do Titular: ");
        int cepef = LerValorInt();
        Conta onta = conta.stream().filter(c -> c.getCpfTitular() ==cepef).findFirst().orElse(null);
        if (onta != null) {
            System.out.println("Digite o valor a ser depositado: ");
            double dinheiro = LerValorInt();
            onta.setSaldo(dinheiro);
        }
    }
    public static void VerificarSaldo(){
        System.out.println("Digite o CPF do Titular: ");
        int cepef = LerValorInt();
        Conta onta = conta.stream().filter(c -> c.getCpfTitular() ==cepef).findFirst().orElse(null);
        if (onta != null) {
            System.out.println("Saldo atual: " + onta.getSaldo());
        } else {
            System.out.println("Operação inválida, conta inexistente.");
        }
    }
    public static void Transferencia(){
        System.out.println("Digite o CPF do Titular: ");
        int cepef = LerValorInt();
        System.out.println("Digite o CPF do Destinatário: ");
        int cepeff = LerValorInt();
        //valores recebidos
        Conta onta = conta.stream().filter(c -> c.getCpfTitular() ==cepef).findFirst().orElse(null);
        Conta konta = conta.stream().filter(c -> c.getCpfTitular() ==cepeff).findFirst().orElse(null);
        if (onta != null && konta != null) {
            System.out.println("Digite o valor a ser depositado: ");
            double dinheiro = LerValorInt();
            if(onta.getSaldo() >= dinheiro){
                dinheiro *= -1;//torna o dinheiro negativo
                onta.setSaldo(dinheiro);
                dinheiro *= -1;//volta para valor positivo
                konta.setSaldo(dinheiro);
            }
        } else {
            System.out.println("Operação inválida!");
        }
    }
    public static void GerContas(){
        Scanner ler5 = new Scanner(System.in);
        System.out.println("|---------------------------------------------------------------------|");
        System.out.println("|Qual opção deseja selecionar?                                        |");
        System.out.println("|1) Criar conta para um cliente                                       |");
        System.out.println("|2) Sacar dinheiro de uma conta de um cliente                         |");
        System.out.println("|3) Depositar dinheiro para uma conta de um cliente                   |");
        System.out.println("|4) Verificar saldo de uma conta de um cliente                        |");
        System.out.println("|5) Transferir dinheiro de uma conta de um cliente para outro cliente |");
        System.out.println("|6) Voltar ao menu inicial                                            |");
        System.out.println("|---------------------------------------------------------------------|");
        int valor = LerValorInt();
        switch(valor){
            case 1:
                CriarConta();
                break;
            case 2:
                SacarValor();
                break;
            case 3:
                DepositarValor();
                break;
            case 4:
                VerificarSaldo();
                break;
            case 5:
                Transferencia();
                break;
            case 6:
                break;
            default:
                System.out.println("Operação inválida.");
                break;
        }
    }
}
/*
Atividade 1
Crie um sistema para gerenciar alunos de uma faculdade e seus cursos e disciplinas!
Com isso, você deverá implementar seu sistema conforme as informações abaixo:
01-Crie um sistema com um MENU com as seguintes opções:
1-Gerenciar ALUNOS
2-Gerenciar DISCIPLINAS
3-Gerenciar CURSOS
4-SAIR
02-Crie um SUBMENU com as seguintes opções para a opção 1:
1-Cadastrar ALUNO
2-Consultar ALUNO
3-Remover ALUNO
4-Atualizar ALUNO
5-Voltar ao MENU INICIAL
03-Crie um SUBMENU com as seguintes opções para a opção 2:
1-Cadastrar DISCIPLINA
2-Consultar DISCIPLINA
3-Remover DISCIPLINA
4-Atualizar DISCIPLINA
5-Voltar ao MENU INICIAL
04-Crie um SUBMENU com as seguintes opções para a opção 3:
1-Cadastrar CURSO
2-Consultar CURSO
3-Remover CURSO
4-Atualizar CURSO
5-Voltar ao MENU INICIAL
05-Desenvolva cada uma das funcionalidades dos SUBMENUS
06-Um ALUNO deve possuir um CURSO (e dados adicionais como nome, idade e etc.)
07-Um CURSO deve pussuir DISCIPLINAS (e dados como nome do curso, turno e etc.)
08-Uma DISCIPLINA deve possuir nome, carga horária, nota e etc.
09-Lembre-se de só sair do programa ao escolher a opção SAIR.
OBS.: utilize LISTAS para salvar os objetos
OBS.: ao mostrar os dados do aluno, o sistema deve mostrar seu curso e todas as
disciplinas
OBS.: ao cadastrar um aluno, deve ser escolhido um dos cursos existentes
OBS.: ao cadastrar uma disciplina, esta deve pertencer a um curso específico

Atividade 2
Crie um sistema para controlar clientes e suas contas bancárias!
Com isso, você deverá implementar seu sistema conforme as informações abaixo:
01-Crie um sistema com um MENU com as seguintes opções:
1-Gerenciar CLIENTES
2-Gerenciar CONTAS
3-SAIR
02-Crie um SUBMENU com as seguintes opções para a opção 1:
1-Cadastrar CLIENTE
2-Consultar CLIENTE
3-Remover CLIENTE
4-Atualizar CLIENTE
5-Voltar ao MENU INICIAL
03-Crie um SUBMENU com as seguintes opções para a opção 2:
1-Criar CONTA para um CLIENTE
2-Sacar dinheiro de uma CONTA de um CLIENTE
3-Depositar dinheiro para uma CONTA de um CLIENTE
4-Verificar saldo de uma CONTA de um CLIENTE
5-Transferir dinheiro de uma CONTA de um CLIENTE para outro CLIENTE
6-Voltar ao MENU INICIAL
*/
