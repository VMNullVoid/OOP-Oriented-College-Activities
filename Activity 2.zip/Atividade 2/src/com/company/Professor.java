package com.company;

public class Professor extends Pessoa{
    private String diploma;
    private int salario;
    public Professor(String nome, String endereco, int idade, String diploma, int salario){
        super(nome,endereco,idade);
        this.diploma = diploma;
        this.salario = salario;
    }
}
