package com.company;

public class Coordenador extends Professor{
private String feedbackGeral;
private String planoEnsino;

    public Coordenador(String nome, String endereco, int idade, String diploma, int salario,String feedbackGeral, String planoEnsino) {
        super(nome, endereco, idade, diploma, salario);
        this.feedbackGeral = feedbackGeral;
        this.planoEnsino = planoEnsino;
    }
}
