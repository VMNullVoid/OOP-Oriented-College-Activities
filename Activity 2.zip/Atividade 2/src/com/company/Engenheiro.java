package com.company;

import java.util.ArrayList;
import java.util.List;

public class Engenheiro extends Funcionario  {
    private String chefe;
    private String RegistroCarteira;
    private List<String> projetos;


    public Engenheiro(String nome, String endereco, Double salario, String cargo, String chefe, String RegistroCarteira, List<String> projetos) {
        super(nome, endereco, salario, cargo);
        this.chefe = chefe;
        this.RegistroCarteira = RegistroCarteira;
        this.projetos = projetos;
    }

    public String getChefe() {
        return chefe;
    }

    public void setChefe(String chefe) {
        this.chefe = chefe;
    }

    public List<String> getProjetos() {
        return projetos;
    }

    public void setProjetos(List<String> projetos) {
        this.projetos = projetos;
    }

    public String getRegistroCarteira() {
        return RegistroCarteira;
    }
}
