package com.company;

public class AlunoSup extends Aluno{
    private int rankPopular;
    private String nomeCrush;
    public AlunoSup(String nome, String endereco, int idade, int matricula, int rankPopular, String nomeCrush){
        super(nome,endereco,idade,matricula);
       this.rankPopular =rankPopular;
       this.nomeCrush = nomeCrush;
    }
}
