package com.company;

public class Tartaruga extends Reptil {

   private int casco;

    public Tartaruga(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, String alimentacao, String habitat, int tipoSangue, int ovosQtde, int casco) {
        super(nome, idade, valor, som, estomagoQtde, conjunto, alimentacao, habitat, tipoSangue, ovosQtde);
        this.casco = casco;
    }
}
