package com.company;

public class Mamifero extends Animal {
    private int tipoSangue;
    private String alimentacao;
    private String filhos;
    private String habitat;

    public Mamifero(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, int tipoSangue, String alimentacao, String filhos, String habitat) {
        super(nome, idade, valor, som, estomagoQtde, conjunto);
        this.habitat = habitat;
        this.alimentacao = alimentacao;
        this.tipoSangue = tipoSangue;
        this.filhos = filhos;
    }
}
