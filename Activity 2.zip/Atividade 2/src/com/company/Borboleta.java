package com.company;

public class Borboleta extends Inseto {

    public Borboleta(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, int asasQtde, String fluidoCorporal, String alimentacao, String habitat) {
        super(nome, idade, valor, som, estomagoQtde, conjunto, asasQtde, fluidoCorporal, alimentacao, habitat);
    }
}
