package com.company;

public class Torneira extends EqEletromecanico{
    private int pressaoAgua;
    public Torneira(String função, int numeros, String problema, int preco, String dono, String caixaFerramenta, String sistemaBase, int pressaoAgua) {
        super(função, numeros, problema, preco, dono, caixaFerramenta, sistemaBase);
        this.pressaoAgua = pressaoAgua;
    }
}
