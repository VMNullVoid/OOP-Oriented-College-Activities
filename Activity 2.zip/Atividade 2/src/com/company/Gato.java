package com.company;

public class Gato extends Mamifero {
    public String dono;
    private int irmaosQtde;
    public String raça;

    public Gato(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, int tipoSangue, String alimentacao, String filhos, String habitat, String dono, int irmaosQtde) {
        super(nome, idade, valor, som, estomagoQtde, conjunto, tipoSangue, alimentacao, filhos, habitat);
        this.dono = dono;
        this.irmaosQtde = irmaosQtde;
    }
}
