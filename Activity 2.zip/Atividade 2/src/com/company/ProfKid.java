package com.company;

public class ProfKid extends Professor{
    public ProfKid(String nome, String endereco, int idade,int salario, String diploma){
        super(nome,endereco,idade,diploma,salario);

    }
}
