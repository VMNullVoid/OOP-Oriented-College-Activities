package com.company;

public class Hidraulico extends EqEletromecanico{
    private int diametroCano;
    public Hidraulico(String função, int numeros, String problema, int preco, String dono, String caixaFerramenta, String sistemaBase, int diametroCano) {
        super(função, numeros, problema, preco, dono, caixaFerramenta, sistemaBase);
        this.diametroCano = diametroCano;
    }
}
