package com.company;

public class Formiga extends Inseto {
private int sociedadeQtde;
private String rainha;

    public Formiga(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, int asasQtde, String fluidoCorporal, String alimentacao, String habitat, int sociedadeQtde, String rainha) {
        super(nome, idade, valor, som, estomagoQtde, conjunto, asasQtde, fluidoCorporal, alimentacao, habitat);
        this.sociedadeQtde = sociedadeQtde;
        this.rainha = rainha;
    }
}
