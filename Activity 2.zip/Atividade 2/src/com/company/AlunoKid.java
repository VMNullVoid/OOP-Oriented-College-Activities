package com.company;

public class AlunoKid extends Aluno{
    private int amiguinhos;
    private String nomeTia;
    public AlunoKid(String nome, String endereco, int idade, int matricula, int amiguinhos, String nomeTia){
        super(nome,endereco,idade,matricula);
        this.amiguinhos = amiguinhos;
        this.nomeTia = nomeTia;
    }
}
