package com.company;

public class ProfSup extends Professor{
    public ProfSup(String nome, String endereco, int idade, int salario,String diploma){
        super(nome,endereco,idade,diploma,salario);

    }
}
