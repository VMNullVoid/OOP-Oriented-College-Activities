package com.company;

public class TV extends EqDomestico{
    private String dimencoes;
    public TV(String função, int numeros, String problema, int preco, String dono, int voltagem, String comodo, String dimencoes) {
        super(função, numeros, problema, preco, dono, voltagem, comodo);
        this.dimencoes = dimencoes;
    }
}
