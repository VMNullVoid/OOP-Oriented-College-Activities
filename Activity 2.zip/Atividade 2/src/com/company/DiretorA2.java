package com.company;

public class DiretorA2 extends Coordenador{
    private String braçoDireito;
    public DiretorA2(String nome, String endereco, int idade, String diploma, int salario, String feedbackGeral, String planoEnsino, String braçoDireito) {
        super(nome, endereco, idade, diploma, salario, feedbackGeral, planoEnsino);
        this.braçoDireito = braçoDireito;
    }
}
