package com.company;

public class Radio extends EqDomestico{
    private String tipoFrequencia;
    public Radio(String função, int numeros, String problema, int preco, String dono, int voltagem, String comodo, String tipoFrequencia) {
        super(função, numeros, problema, preco, dono, voltagem, comodo);
        this.tipoFrequencia = tipoFrequencia;
    }
}
