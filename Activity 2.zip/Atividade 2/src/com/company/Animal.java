package com.company;

public class Animal {
    private String nome;
    private int idade;
    private double valor;
    private String som;
    private int estomagoQtde;
    private String conjunto;

    public Animal(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto){
        this.nome = nome;
        this.idade = idade;
        this.valor = valor;
        this.som = som;
        this.estomagoQtde = estomagoQtde;
        this.conjunto = conjunto;
    }
}
