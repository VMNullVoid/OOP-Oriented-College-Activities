package com.company;

public class EqDomestico extends Equipamento{
    private String dono;
    private int voltagem;
    private String comodo;
    public EqDomestico(String função, int numeros, String problema, int preco, String dono, int voltagem, String comodo) {
        super(função, numeros, problema, preco);
        this.dono = dono;
        this.voltagem = voltagem;
        this.comodo = comodo;
    }
}
