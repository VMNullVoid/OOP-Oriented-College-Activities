package com.company;

public class Passaro extends Ave {

    public Passaro(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, int asasQtde, String alimentacao, String habitat, int tipoSangue, int ovosQtde) {
        super(nome, idade, valor, som, estomagoQtde, conjunto, asasQtde, alimentacao, habitat, tipoSangue, ovosQtde);
    }
}
