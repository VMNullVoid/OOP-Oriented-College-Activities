package com.company;

public class Main {

    public static void main(String[] args) {
     //acabado 23:58
    }
}
/*
Questão 1:
Implemente através da linguagem Java a herança que compõe uma superclasse que
representa um Artista e subclasses de Cantores, Tecladistas, Guitarristas e Bateristas.
Organize as classes de forma a garantir a herança entre as classes, definindo os principais
atributos e métodos para cada classe.
Questão 2:
Implemente através da linguagem Java a herança que compõe uma superclasse que
representa um Funcionário e subclasses de Engenheiros, Diretores, Secretários, Gerentes,
Analistas e Advogados.
Organize as classes de forma a garantir a herança entre as classes, definindo os principais
atributos e métodos para cada classe.
Questão 3:
Implemente através da linguagem Java a herança que compõe uma superclasse que
representa um Animal e subclasses de Insetos, Peixes, Répteis, Aves, Mamíferos, Lobos,
Coelhos, Cachorros, Gatos, Crocodilos, Tartarugas, Águias, Pássaros, Borboletas e Formigas.
Organize as classes de forma a garantir a herança entre as classes, definindo os principais
atributos e métodos para cada classe.
Questão 4:
Implemente através da linguagem Java a herança que compõe uma superclasse que
representa uma Pessoa e subclasses de Alunos, Professores, Alunos do Ensino Primário,
Alunos do Ensino Superior, Professores do Ensino Primário, Professores do Ensino Superior,
Coordenadores de cursos que também atuam como Professores e Diretores.
Organize as classes de forma a garantir a herança entre as classes, definindo os principais
atributos e métodos para cada classe.
Questão 5:
Implemente através da linguagem Java a herança que compõe uma superclasse que
representa um Equipamento e subclasses de Equipamentos Eletrodomésticos,
Eletromecânicos, Hidráulicos, Torneiras, Motores elétricos, TVs, DVDs e Rádios
Organize as classes de forma a garantir a herança entre as classes, definindo os principais
atributos e métodos para cada classe.
 */
