package com.company;

public class Ave extends Animal {
    private int tipoSangue;
    private int asasQtde;
    private String alimentacao;
    private int ovosQtde;
    private String habitat;

    public Ave(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, int asasQtde, String alimentacao, String habitat, int tipoSangue, int ovosQtde) {
        super(nome, idade, valor, som, estomagoQtde, conjunto);
        this.habitat = habitat;
        this.ovosQtde = ovosQtde;
        this.alimentacao = alimentacao;
        this.tipoSangue = tipoSangue;
        this.asasQtde = asasQtde;
    }
}
