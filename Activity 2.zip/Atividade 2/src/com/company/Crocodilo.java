package com.company;

public class Crocodilo extends Reptil {

private int dentes;
    public Crocodilo(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, String alimentacao, String habitat, int tipoSangue, int ovosQtde, int dentes) {
        super(nome, idade, valor, som, estomagoQtde, conjunto, alimentacao, habitat, tipoSangue, ovosQtde);
        this.dentes = dentes;
    }
}
