package com.company;

import java.util.List;

public class Lobo extends Mamifero{
    private List<String> Hierarquia;
    public String lider;

    public Lobo(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, int tipoSangue, String alimentacao, String filhos, String habitat, List<String> Hierarquia, String lider) {
        super(nome, idade, valor, som, estomagoQtde, conjunto, tipoSangue, alimentacao, filhos, habitat);
        this.Hierarquia = Hierarquia;
        this.lider = lider;
    }
}
