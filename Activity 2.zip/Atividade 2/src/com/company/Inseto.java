package com.company;

public class Inseto extends Animal {
    private int asasQtde;
    private String fluidoCorporal;
    private String alimentacao;
    private String habitat;

    public Inseto(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, int asasQtde, String fluidoCorporal, String alimentacao, String habitat) {
        super(nome, idade, valor, som, estomagoQtde, conjunto);
        this.alimentacao = alimentacao;
        this.asasQtde = asasQtde;
        this.fluidoCorporal = fluidoCorporal;
        this.habitat = habitat;

    }
}
