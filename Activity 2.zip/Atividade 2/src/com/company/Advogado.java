package com.company;

import java.util.ArrayList;
import java.util.List;

public class Advogado extends Funcionario {
    private String clienteAt;
    private String PJe;
    private List<String> processos;

    public Advogado(String nome, String endereco, Double salario, String cargo, String clienteAt, String PJe, List<String> processos) {
        super(nome, endereco, salario, cargo);
        this.clienteAt = clienteAt;
        this.PJe = PJe;
        this.processos = processos;
    }

    public String getPJe() {
        return PJe;
    }

    public String getClienteAt() {
        return clienteAt;
    }

    public void setClienteAt(String clienteAt) {
        this.clienteAt = clienteAt;
    }

    public List<String> getProcessos() {
        return processos;
    }

    public void setProcessos(List<String> processos) {
        this.processos = processos;
    }
}
