package com.company;

public class Peixe extends Animal {
    private int tipoSangue;
    private String alimentacao;
    private int ovosQtde;
    private String habitat;

    public Peixe(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, String alimentacao, String habitat, int tipoSangue, int ovosQtde) {
        super(nome, idade, valor, som, estomagoQtde, conjunto);
        this.habitat = habitat;
        this.ovosQtde = ovosQtde;
        this.alimentacao = alimentacao;
        this.tipoSangue = tipoSangue;
    }
}
