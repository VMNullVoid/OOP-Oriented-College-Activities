package com.company;

public class Tecladista extends Artista {
    private String instrumento;
    private int instrumentoQtde;

    public Tecladista(int idade, String nome, String instrumento, int instrumentoQtde){
        super(idade,nome);
        this.instrumento = instrumento;
        this.instrumentoQtde = instrumentoQtde;
    }
    public String getInstrumento() {
        return instrumento;
    }

    public void setInstrumento(String instrumento) {
        this.instrumento = instrumento;
    }

    public int getInstrumentoQtde() {
        return instrumentoQtde;
    }

    public void setInstrumentoQtde(int instrumentoQtde) {
        this.instrumentoQtde = instrumentoQtde;
    }
}
