package com.company;

import java.util.List;

public class Cachorro extends Lobo {
      public String dono;
      private int irmaosQtde;
      public String raça;

    public Cachorro(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, int tipoSangue, String alimentacao, String filhos, String habitat, List<String> Hierarquia, String lider, String dono, int irmaosQtde) {
        super(nome, idade, valor, som, estomagoQtde, conjunto, tipoSangue, alimentacao, filhos, habitat, Hierarquia, lider);
        this.dono = dono;
        this.irmaosQtde = irmaosQtde;
    }
}
