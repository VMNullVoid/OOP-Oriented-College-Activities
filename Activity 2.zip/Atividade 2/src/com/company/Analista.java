package com.company;

public class Analista extends Funcionario {
    private String chefe;
    private String RegistroCarteira;

    public Analista(String nome, String endereco, Double salario, String cargo, String chefe, String RegistroCarteira) {
        super(nome, endereco, salario, cargo);
        this.chefe = chefe;
        this.RegistroCarteira = RegistroCarteira;
    }

    public String getRegistroCarteira() {
        return RegistroCarteira;
    }

    public String getChefe() {
        return chefe;
    }

    public void setChefe(String chefe) {
        this.chefe = chefe;
    }
}
