package com.company;

public class Gerente extends Diretor {
    private String RegistroCarteira;

    public Gerente(String nome, String endereco, Double salario, String cargo, String subalterno, String RegistroCarteira) {
        super(nome, endereco, salario, cargo, subalterno, RegistroCarteira);

    }

    @Override
    public String getRegistroCarteira() {
        return RegistroCarteira;
    }
}
