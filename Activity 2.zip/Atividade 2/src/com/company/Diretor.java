package com.company;

public class Diretor extends Funcionario  {
    private String subalterno;
    private String RegistroCarteira;

    public Diretor(String nome, String endereco, Double salario, String cargo, String subalterno, String RegistroCarteira) {
        super(nome, endereco, salario, cargo);
        this.subalterno = subalterno;
        this.RegistroCarteira = RegistroCarteira;
    }

    public String getRegistroCarteira() {
        return RegistroCarteira;
    }

    public String getSubalterno() {
        return subalterno;
    }

    public void setSubalterno(String subalterno) {
        this.subalterno = subalterno;
    }
}
