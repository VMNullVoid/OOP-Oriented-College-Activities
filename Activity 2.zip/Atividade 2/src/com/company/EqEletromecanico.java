package com.company;

public class EqEletromecanico extends Equipamento{
    private String dono;
    private String caixaFerramenta;
    private String sistemaBase;
    public EqEletromecanico(String função, int numeros, String problema, int preco, String dono, String caixaFerramenta, String sistemaBase) {
        super(função, numeros, problema, preco);
        this.dono = dono;
        this.caixaFerramenta = caixaFerramenta;
        this.sistemaBase = sistemaBase;
    }
}
