package com.company;

public class Secretario extends Funcionario  {
    private String chefe;
    private String RegistroCarteira;
    private String agenda;

    public Secretario(String nome, String endereco, Double salario, String cargo, String chefe, String RegistroCarteira, String agenda) {
        super(nome, endereco, salario, cargo);
        this.chefe = chefe;
        this.RegistroCarteira = RegistroCarteira;
        this.agenda = agenda;
    }

    public String getAgenda() {
        return agenda;
    }

    public void setAgenda(String agenda) {
        this.agenda = agenda;
    }

    public String getRegistroCarteira() {
        return RegistroCarteira;
    }

    public String getChefe() {
        return chefe;
    }

    public void setChefe(String chefe) {
        this.chefe = chefe;
    }
}
