package com.company;

public class Equipamento {
    private String função;
    private int numeros;
    private String problema;
    private int preco;
    public Equipamento(String função, int numeros, String problema, int preco){
        this.função = função;
        this.numeros = numeros;
        this.problema = problema;
        this.preco = preco;
    }
}
