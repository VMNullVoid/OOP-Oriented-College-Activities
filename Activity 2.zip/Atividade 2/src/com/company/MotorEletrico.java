package com.company;

public class MotorEletrico extends EqEletromecanico{
    private String alimentacaoMotor;
    public MotorEletrico(String função, int numeros, String problema, int preco, String dono, String caixaFerramenta, String sistemaBase, String alimentacaoMotor) {
        super(função, numeros, problema, preco, dono, caixaFerramenta, sistemaBase);
        this.alimentacaoMotor = alimentacaoMotor;
    }
}
