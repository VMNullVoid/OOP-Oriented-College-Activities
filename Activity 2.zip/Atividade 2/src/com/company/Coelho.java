package com.company;

public class Coelho extends Mamifero {

    private int filhosQtde;

    public Coelho(String nome, int idade, double valor, String som, int estomagoQtde, String conjunto, int tipoSangue, String alimentacao, String filhos, String habitat, int filhosQtde) {
        super(nome, idade, valor, som, estomagoQtde, conjunto, tipoSangue, alimentacao, filhos, habitat);
        this.filhosQtde = filhosQtde;
    }
}
