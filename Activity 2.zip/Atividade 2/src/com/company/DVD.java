package com.company;

public class DVD extends EqDomestico{
    private String tipoLeitor;
    public DVD(String função, int numeros, String problema, int preco, String dono, int voltagem, String comodo, String tipoLeitor) {
        super(função, numeros, problema, preco, dono, voltagem, comodo);
        this.tipoLeitor = tipoLeitor;
    }
}
