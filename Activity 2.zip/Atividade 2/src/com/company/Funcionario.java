package com.company;

public class Funcionario {
private String nome;
private String endereco;
private Double salario;
private String cargo;

public Funcionario(String nome, String endereco, Double salario, String cargo){
    this.nome = nome;
    this.endereco = endereco;
    this.salario = salario;
    this.cargo = cargo;
}

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
}
