package com.company;

public class Artista {
    private int idade;
    private String nome;

    public Artista(int idade, String nome){
        this.idade = idade;
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getNome() {
        return nome;
    }
}
