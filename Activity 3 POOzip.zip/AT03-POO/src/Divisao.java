import java.util.Scanner;

public class Divisao extends Calculadora{

    public Divisao(int inicial, int secundario, double Inicial, double Secundario) {
        super(inicial, secundario, Inicial, Secundario);
        Scanner input = new Scanner(System.in);
        System.out.println("Informe o primeiro valor: ");
        inicial = Integer.parseInt(String.valueOf(input));
        System.out.println("Informe o segundo valor: ");
        secundario = Integer.parseInt(String.valueOf(input));
        dividir(inicial, secundario);

        System.out.println("Informe o primeiro valor: ");
        inicial = Integer.parseInt(String.valueOf(input));
        Inicial = (double) inicial;
        System.out.println("Informe o segundo valor: ");
        Secundario = Integer.parseInt(String.valueOf(input));
        Secundario = (double) secundario;
        dividir(Inicial, Secundario);
    }
}
