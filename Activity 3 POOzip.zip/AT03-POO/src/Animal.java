public class Animal {
    String som;
    int qtdeSom;



    public Animal(String som, int qtdeSom){
        this.som = som;
        this.qtdeSom = qtdeSom;
    }
    public void emiteSom(String som, int qtdeSom) {
        for(int i = 0; i <= qtdeSom; i++){
            System.out.println(som);
        }// viu o meu ?
    }
}
