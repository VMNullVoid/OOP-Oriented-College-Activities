public class Moto extends Veiculo {
    public Moto(){

    }
    @Override
    public void aumentarVelocidade(int velocidade,int vAtual, int marcha, int mAtual){
        if(velocidade > vAtual && marcha > mAtual && velocidade < 100 & marcha < 4){
            vAtual = velocidade;
            mAtual = marcha;
        }else
            System.out.println("Comando inválido! O carro morreu! ");
    }
    @Override
    public void diminuirVelocidade(int velocidade,int vAtual, int marcha, int mAtual){
        if(velocidade < vAtual && marcha < mAtual && velocidade > 0 && marcha > 1){
            vAtual = velocidade;
            mAtual = marcha;
        }else
            System.out.println("Comando inválido! O carro derrapou e você bateu! ");
    }
}
