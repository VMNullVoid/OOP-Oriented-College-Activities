public class Alcool extends SubsPura{
    public Alcool(double PE, double PF, String mensagem) {
        super(PE, PF, mensagem);
        this.PE = PE;
        this.PF = PF;
        this.mensagem = mensagem;
        mensagem = "Álcool em Ebulição!";
       // PF = 0;
      //  PE = 78.4;
       // entrarPontoDeEbulicao(mensagem,PE);
        //entrarPontoDeFusao(mensagem, PF);
    }
    @Override
    public void entrarPontoDeEbulicao(String mensagem, double PE) {
        mensagem = "Álcool em Ebulição! ";
        PE = 78.4;
        super.entrarPontoDeEbulicao(mensagem, PE);
    }
    @Override
    public void entrarPontoDeFusao(String mensagem, double PF){
        mensagem = "Álcool em Fusão! ";
        PF = 0;
        super.entrarPontoDeFusao(mensagem, PF); //
    }
}
