import java.util.Scanner;

public class Desktop extends Computador{
    String modelo;
    String so;
    String gabinete;
    int telasQtde;
    public Desktop(int largura, int altura, String cor, String modelo, String so, String gabinete, int telasQtde) {
        super(largura, altura, cor);
        this.modelo = modelo;
        this.so = so;
        this.gabinete = gabinete;
        this.telasQtde = telasQtde;
    }
    @Override
    public void informaCaracterísticas(int largura, int altura, String cor){
        informaTela(largura, altura);
        informaCor(cor);
        System.out.println("Largura: "+ largura +"\nAltura: "+ altura +"\nCor: "+cor);
        System.out.println("Sistema Operacional: "+ so +"\nGabinete: "+ gabinete +"\nQuantidade de Telas: "+telasQtde);
    }
    @Override
    public void informaTela(int largura, int altura){
        System.out.println("Informe a largura da tela");
        largura = lerValorInt();
        System.out.println("Informe a altura da tela");
        altura = lerValorInt();
    }
    @Override
    public void informaCor(String cor){
        Scanner coor = new Scanner(System.in);
        System.out.println("Informe a cor do aparelho");
        cor = coor.next();
        // this.cor = String.valueOf(cores);
    }

    public static int lerValorInt() {
        Scanner valor = new Scanner(System.in);
        return valor.nextInt();
    }
}
