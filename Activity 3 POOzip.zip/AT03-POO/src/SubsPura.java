public class SubsPura {
    double PE; //ebulição
    double PF; //fusão
    String mensagem; //mensagem de aviso
    public void entrarPontoDeEbulicao(String mensagem,double PE){
        System.out.println(mensagem + PE +"Graus Celsius");
    }
    public void entrarPontoDeFusao(String mensagem,double PF){
     System.out.println(mensagem + PF +"Graus Celsius");
    }

    public SubsPura(double PE, double PF, String mensagem){
        this.mensagem = mensagem;
        this.PE = PE;
        this.PF = PF;
    }
}
