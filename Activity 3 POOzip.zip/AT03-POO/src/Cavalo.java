import java.util.Queue;

public class Cavalo extends Animal{

    public Cavalo(String som, int qtdeSom) {
        super(som, qtdeSom);
        this.som = som;
        this. qtdeSom = 1;
        som = "Íihhehee ";
        qtdeSom = 1;
       //EmitirSom(som, qtdeSom);    construtor
    }
    @Override
    public void emiteSom(String som, int qtdeSom) {
        super.emiteSom(som, qtdeSom);
    }
}
