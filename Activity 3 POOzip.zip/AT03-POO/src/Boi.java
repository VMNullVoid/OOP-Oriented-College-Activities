public class Boi extends Animal{
    public Boi(String som, int qtdeSom) {
        super(som, qtdeSom);
        som = "Moo ";
        qtdeSom = 2;
       // EmitirSom(som, qtdeSom);
    }
    @Override
    public void emiteSom(String som, int qtdeSom) {
        super.emiteSom(som, qtdeSom);
    }
}
