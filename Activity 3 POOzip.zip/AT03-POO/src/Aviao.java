public class Aviao extends Veiculo {
    int altitude;
    int alAtual;
    int resistenciaAr;
    int resAtual;

    public Aviao(){

    }
    public void aumentarVelocidade(int velocidade,int vAtual,int altitude,int aAtual, int resistenciaAr, int resAtual){
        if(velocidade > vAtual && altitude > aAtual & resistenciaAr < resAtual & velocidade < 1000 & altitude < 3000 & resistenciaAr < 50){
            vAtual = velocidade;
            aAtual = altitude;
            resAtual = resistenciaAr;

        }else
            System.out.println("Comando inválido! O avião se manteve como estava. ");
    }

    public void diminuirVelocidade(int velocidade,int vAtual,int altitude,int aAtual, int resistenciaAr, int resAtual){
        if(velocidade < vAtual && altitude < aAtual & resistenciaAr > resAtual & velocidade > 100 & altitude > 1000 & resistenciaAr > 100){
            vAtual = velocidade;
            aAtual = altitude;
            resAtual = resistenciaAr;
        }else
            System.out.println("Comando inválido! Apertem os cintos! o Avião está sem controle! ");
    }
}
