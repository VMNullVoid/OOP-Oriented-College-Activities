public class Veiculo {
    int velocidade;
    int vAtual;
    int marcha;
    int mAtual;

    public Veiculo(){

    }
   public void aumentarVelocidade(int velocidade,int vAtual, int marcha, int mAtual){
     vAtual += velocidade;
     mAtual += marcha;
    }
    public void diminuirVelocidade(int velocidade,int vAtual, int marcha, int mAtual){
        vAtual -= velocidade;
        mAtual = marcha;
    }
}
