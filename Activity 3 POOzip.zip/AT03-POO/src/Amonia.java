public class Amonia extends SubsPura{
    public Amonia(double PE, double PF, String mensagem) {
        super(PE, PF, mensagem);

        this.mensagem = mensagem;
        this.PF = -77.73;
        this.PE = -33.34;
      // entrarPontoDeEbulicao(mensagem,PE);
        //entrarPontoDeFusao(mensagem, PF);
    }
    @Override
    public void entrarPontoDeEbulicao(String mensagem, double PE) {
        mensagem = "Amônia em Ebulição! ";
        PE = -33.34;
        super.entrarPontoDeEbulicao(mensagem, PE);
    }
    @Override
    public void entrarPontoDeFusao(String mensagem, double PF){
        mensagem = "Amônia em Fusão! ";
        PF = -77.73;
        super.entrarPontoDeFusao(mensagem, PF); //
    }
}
