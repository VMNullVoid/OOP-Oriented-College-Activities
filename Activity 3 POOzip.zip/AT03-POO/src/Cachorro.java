public class Cachorro extends Animal{
    public Cachorro(String som, int qtdeSom) {
        super(som, qtdeSom);
        som = "Au ";
        qtdeSom = 4;
        /// EmitirSom(som, qtdeSom);
    }
    @Override
    public void emiteSom(String som, int qtdeSom) {
        super.emiteSom(som, qtdeSom);
    }
}
