public class Gato extends Animal{
    public Gato(String som, int qtdeSom) {
        super(som, qtdeSom);
        som = "Miau miaaaau";
        qtdeSom = 3;
        // EmitirSom(som, qtdeSom);
    }
    @Override
    public void emiteSom(String som, int qtdeSom) {
        super.emiteSom(som, qtdeSom);
    }
}
