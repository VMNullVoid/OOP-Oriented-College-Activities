public class Main {
    public static void main(String[] args) {

    }
}
/*
Questão 1:
Implemente através da linguagem Java a herança que compõe uma superclasse que
representa um Animal e subclasses de Gato, Cachorro, Cavalo, Leão e Boi. Sendo assim, usando
os conceitos polimorfismo de sobrescrita, implemente o método emitirSom() para cada classe,
considerando as condições abaixo:
● O gato mia;
● O cachorro late;
● O cavalo relincha;
● O leão ruge;
● O boi muge

Questão 2:
Implemente através da linguagem Java a herança que compõe uma superclasse que
representa uma Substância pura e subclasses de Água, Amônia e Álcool. Sendo assim, usando
os conceitos polimorfismo de sobrescrita, implemente os métodos entrarPontoDeEbulicao() e
entrarPontoDeFusao(), de forma que os dois métodos recebam valores decimais considerando as
condições abaixo:

● Água (Ponto de ebulição: 100 oC - Ponto de fusão: 0 oC)
● Amônia (Ponto de ebulição: -33,34 °C - Ponto de fusão: -77,73 °C)
● Álcool (Ponto de ebulição: 78,4 °C - Ponto de fusão: 0 oC)

Questão 3:
Implemente através da linguagem Java a herança que compõe uma superclasse que
representa uma Calculadora e subclasses de Multiplicação, Divisão, Subtração e Adição. Sendo
assim, usando os conceitos polimorfismo de sobrescrita e sobrecarga, implemente o método
calcular() para cada classe, de forma que receba valores do tipo inteiro e decimal.
Questão 4:
Implemente através da linguagem Java a herança que compõe uma superclasse que
representa um Computador e subclasses de Desktop, Notebooks e Ultrabooks. Sendo assim,
usando os conceitos polimorfismo de sobrescrita e sobrecarga, implemente o método
informaCaracterísticas() para cada classe, de forma que exista um método que define só o
tamanho da tela, um método que define a cor e um método que define o tamanho da tela e a cor.
Questão 5:
Implemente através da linguagem Java a herança que compõe uma superclasse que
representa um Veículo e subclasses de Carro, Moto e Avião. Sendo assim, usando os conceitos
polimorfismo de sobrescrita e sobrecarga, implemente os métodos aumentarVelocidade() e
diminuirVelocidade() para cada classe, considerando as condições abaixo:

● O carro ganha velocidade recebendo um valor da nova velocidade e da nova marcha
a ser modificada. Neste caso, só irá aumentar a velocidade se a velocidade e a
marcha recebidas por parâmetro forem maiores que as atuais. Além disso, a
velocidade não pode ser maior que 200 km/h e a marcha maior que 5.
● O carro perde velocidade recebendo um valor da nova velocidade e da nova marcha

a ser modificada. Neste caso, só irá diminuir a velocidade se a velocidade e a
marcha recebidas por parâmetro forem menores que as atuais. Além disso, a
velocidade não pode ser menor que 0 km/h e a marcha menor que 1.
● A moto ganha velocidade recebendo um valor da nova velocidade e da nova marcha
a ser modificada. Neste caso, só irá aumentar a velocidade se a velocidade e a
marcha recebidas por parâmetro forem maiores que as atuais. Além disso, a
velocidade não pode ser maior que 100 km/h e a marcha maior que 4.
● A moto perde velocidade recebendo um valor da nova velocidade e da nova marcha
a ser modificada. Neste caso, só irá diminuir a velocidade se a velocidade e a
marcha recebidas por parâmetro forem menores que as atuais. Além disso, a
velocidade não pode ser menor que 0 km/h e a marcha menor que 1.
● O avião ganha velocidade recebendo um valor da nova velocidade, da nova altitude
e da nova resistência do ar a ser modificada. Neste caso, só irá aumentar a
velocidade se a velocidade e a altitude recebidas por parâmetro forem maiores que
as atuais e a resistência atual for menor que a atual. Além disso, a velocidade não
pode ser maior que 1000 km/h, a altitude não pode ser maior que 3000 metros e a
resistência do ar deve ser menor que 50.
● O avião perde velocidade recebendo um valor da nova velocidade, da nova altitude e
da nova resistência do ar a ser modificada. Neste caso, só irá diminuir a velocidade
se a velocidade e a altitude recebidas por parâmetro forem menores que as atuais e
a resistência atual for maior que a atual. Além disso, a velocidade não pode ser
menor que 100 km/h, a altitude não pode ser menor que 1000 metros e a resistência
do ar deve ser maior que 100.
 */