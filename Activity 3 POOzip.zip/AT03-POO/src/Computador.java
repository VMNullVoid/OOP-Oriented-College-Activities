import java.util.Scanner;

public class Computador {
    int largura;
    int altura;
    String cor;

    public Computador(int largura, int altura, String cor){
        informaCaracterísticas(largura, altura, cor);
        this.largura = largura;
        this.altura = altura;
        this.cor = cor;
    }

    public void informaCaracterísticas(int largura, int altura, String cor){
        informaTela(largura, altura);
        informaCor(cor);
    }
    public void informaTela(int largura, int altura){
        System.out.println("Informe a largura da tela");
        largura = lerValorInt();
        System.out.println("Informe a altura da tela");
        altura = lerValorInt();
    }
    public void informaCor(String cor){
        Scanner coor = new Scanner(System.in);
        System.out.println("Informe a cor do aparelho");
        cor = coor.next();
    }
    public static int lerValorInt() {
        Scanner valor = new Scanner(System.in);
        return valor.nextInt();
    }
}
