public class Leão extends Animal{
    public Leão(String som, int qtdeSom) {
        super(som, qtdeSom);
        som = "RAAAAUUGGGHHHH ";
        qtdeSom = 1;
        // EmitirSom(som, qtdeSom);
    }@Override
    public void emiteSom(String som, int qtdeSom) {
        super.emiteSom(som, qtdeSom);
    }
}
