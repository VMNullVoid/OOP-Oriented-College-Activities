public class Calculadora {
    int inicial;
    int secundario;
    int resultado;
    double Inicial;
    double Secundario;


    public Calculadora(int inicial, int secundario,double Inicial, double Secundario){
        this.inicial = inicial;
        this.secundario = secundario;
        this.Inicial = Inicial;
        this.Secundario = Secundario;
    }
    public void somar(int inicial, int secundario){
        System.out.println(inicial + secundario);
    }
    public void somar(double Inicial, double Secundario){
        System.out.println(inicial + secundario);
    }
    public void subtrair(int inicial, int secundario){
        System.out.println(inicial - secundario);
    }
    public void subtrair(double Inicial, double Secundario){
        System.out.println(inicial - secundario);
    }
    public void multiplicar(int inicial, int secundario){
        resultado =  inicial * secundario;
        System.out.println(resultado);
    }
    public void multiplicar(double Inicial, double Secundario){
        resultado =  inicial * secundario;
        System.out.println(resultado);
    }
    public void dividir(int inicial, int secundario){
        if(inicial >= secundario){
        System.out.println(inicial / secundario);}
        else
            System.out.println("não foi possível executar a operação.");
    }
    public void dividir(double Inicial, double Secundario){
        if(inicial >= secundario){
            System.out.println(inicial / secundario);}
        else
            System.out.println("não foi possível executar a operação.");
    }
}
