public class Agua extends SubsPura{
    public Agua(double PE, double PF, String mensagem) {
        super(PE, PF, mensagem);
        this.PE = PE;
        this.PF = PF;
        this.mensagem = mensagem;
       // mensagem = "Água em Ebulição!";
       // PF = 0;
      //  PE = 100;
        //entrarPontoDeEbulicao(mensagem,PE);//ss
        entrarPontoDeFusao(mensagem, PF);
    }
    @Override
    public void entrarPontoDeEbulicao(String mensagem, double PE) {
        mensagem = "Água em Ebulição! ";
        PE =100;
        super.entrarPontoDeEbulicao(mensagem, PE);
    }
    @Override
    public void entrarPontoDeFusao(String mensagem, double PF){
        mensagem = "Água em Fusão! ";
        PF = 0;
        super.entrarPontoDeFusao(mensagem, PF); //
    }
}
