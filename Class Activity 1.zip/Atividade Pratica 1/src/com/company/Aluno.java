package com.company;

public class Aluno {
    private String Nome;
    private String Matricula;
    private String Endereco;
    private String Idade;
    public String CPF;

    public Aluno(String Nome, String CPF){
        this.Nome = Nome;
        this.CPF = CPF;
    }
    public void updateEnderecoAluno(String Endereco){
        this.Endereco = Endereco;
    }
    public void matricular(String Matricula){
      this.Matricula = Matricula;
      System.out.println("O aluno" + this.Nome +"  se matriculou!");

    }
}
