package com.company;

import java.util.ArrayList;
import java.util.List;

public class BusaoEnterprise {
public String Nome;
public String CNPJ;
public List<Onibus> frota = new ArrayList<>();

public BusaoEnterprise(String Nome,String CNPJ){

}
}
