package com.company;

import java.util.ArrayList;
import java.util.List;

public class Banco {
    public String nome;
    public String cnpj;
    public String endereco;
    public List<Conta> contas;

    public Banco(String nome, String cnpj, String endereco){
        this.nome = nome;
        this.cnpj = cnpj;
        this.endereco = endereco;
        contas = new ArrayList<>();
    }
    public void addConta(Conta conta){
        this.contas.add(conta);
    }
    //freestyle
}
