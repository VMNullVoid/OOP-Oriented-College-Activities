package com.company;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;

public class Cliente {
    public int codigo;
    public String nome;
    public String cpf;
    public String endereco;
    public List<Conta> contas;

    public Cliente(int codigo, String nome, String cpf, String endereco){
        this.cpf = cpf;
        this.endereco = endereco;
        this.nome = nome;
        this.codigo = codigo;
        this.contas = new ArrayList<>();
    }
    public void CriarCliente(Conta conta){
        this.contas.add(conta);
    }
    public void depositar(Conta conta, double valor){
        Conta contaGet = this.contas.stream().filter(c -> c == conta).findFirst().get();
        contaGet.Depositar(valor);
    }
    public void ImprimirContas(){
        for(Conta conta : contas){
            System.out.println("Número: " + conta.Numero_conta);
            System.out.println("Tipo: " + conta.tipo);
            System.out.println("Data de criação: " + conta.data);
            System.out.println("Saldo da conta: " + conta.saldo);
        }
    }
}


