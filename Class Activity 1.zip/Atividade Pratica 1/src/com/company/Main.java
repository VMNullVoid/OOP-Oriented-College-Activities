package com.company;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
//Cheguei em casa às 23:52 professor.
    public static void main(String[] args) {
// listas de apoio a algum exercício
        List<Conta> Contas_Banco = new ArrayList<>();
        List<Cliente> ClientesDaqui = new ArrayList<>();
//variáveis de auxilio a alguma função
        int CountCli = 0;
        //abaixo partes dos exercícios 1 e 2 feitos na sala!

        BusaoEnterprise emp1 = new BusaoEnterprise("Cabarret", "10294yu120");
        Onibus o1 = new Onibus(12);
        Onibus o2 = new Onibus(2);
        Onibus o3 = new Onibus(1);

        Scanner ler = new Scanner(System.in);
        System.out.println("Informe o CNPJ da faculdade: ");
        String cnpjFaculdade = ler.next();
        System.out.println("Informe o nome da faculdade: ");
        String nomeFaculdade = ler.next();
        System.out.println("Informe o endereço da faculdade: ");
        String enderecoFaculdade = ler.next();
        Faculdade faculdade1 = new Faculdade(cnpjFaculdade,nomeFaculdade,enderecoFaculdade);

      Aluno A1 = new Aluno("Leonardo", "23542564" );
        Aluno A2 = new Aluno("Maria", "46456546" );
        Aluno A3 = new Aluno("Mawera","325235432");
       faculdade1.AddAluno(A1);
       faculdade1.AddAluno(A2);
       faculdade1.AddAluno(A3);
       A1.matricular("0001");
       A2.matricular("0002");
       A3.matricular("0003");
       //Menu();

        Banco banco = new Banco("Itau","01010101", "rua1");
        Cliente cliente1 = new Cliente(1,"Joaquim","0101","rua1");
        Cliente cliente2 = new Cliente(2,"Joaq2134","0102","rua2");
        Cliente cliente3 = new Cliente(3,"Xandao","0157","rua9");

        Conta conta1 = new Conta("0101", 1, "01/01/2023");
        Conta conta2 = new Conta("0102", 1, "02/05/2023");
        Conta conta3 = new Conta("0103", 2, "8/02/2023");

        cliente1.CriarCliente(conta1);
        cliente2.CriarCliente(conta1);
        cliente3.CriarCliente(conta1);

        cliente1.contas.get(0).Depositar(1000);
        cliente1.contas.get(0).SacarValor(50);

        cliente1.contas.get(0).Transferir(100, cliente2.contas.get(0));
    }

    //parte para os leitores de valor inteiro e string
    public static int lerValorInt() {
        Scanner valor = new Scanner(System.in);
        return valor.nextInt();
    }
    public static String lerValorString() {
        Scanner valor = new Scanner(System.in);
        return valor.nextLine();
    }
}

    /*menu da atividade 3
    public static void Menu(){
        while(true){
            System.out.println("|-------------------------------|");
            System.out.println("| 1)Cadastrar uma conta         |");
            System.out.println("| 2)Sacar valor                 |");
            System.out.println("| 3)Depositar valor             |");
            System.out.println("| 4)Verificar saldo             |");
            System.out.println("|-------------------------------|");
            int r = lerValorInt();
            switch (r){
                case 1:{
                    CriarConta();
                    break;
                }
                case 2:{
                   SacarValor();
                    break;
                }
                case 3:{
                    Depositar();
                    break;
                }
                case 4:{
                    VerificarSaldo();
                    break;
                }
            }
        }
    }
}*/
//
//
//
/*
Exercício 1
● Crie a estrutura da classe das entidades: Faculdade, Aluno, Escola
○ Cada classe deverá conter pelo menos 5 atributos
● Crie os objetos e instâncias para cada entidade
○ Atribue valores para os objetos criados
● Altere suas classes de forma a possuir pelo menos 2 métodos cada classe
○ Você poderá utilizar o recurso ex.: System.out.println(“O aluno se matriculou”)
para simular comportamentos e ações dos objetos.

Exercício 2

a. Crie as classes abaixo:
● Uma classe que represente uma empresa de ônibus. Crie atributos e métodos para
representar esta classe.
● Uma classe que represente os ônibus desta empresa. Crie atributos e métodos para
representar esta classe. Além disso, crie uma forma para relacionar os ônibus à
empresa.
○ A classe ônibus deve conter obrigatoriamente:
■ atributos do ônibus, quilometragem rodada(double), quantidade de
pessoas(int), e nome do motorista(String).
■ um método ou construtor que permita cadastrar um novo ônibus.
■ um método que permita verificar a quilometragem do ônibus, sendo
que acima de 200km o ônibus é impossibilitado de rodar.
■ um método que permita adicionar novas pessoas ao ônibus, sendo
que o limite máximo deve ser de 60 pessoas.
■ um método que premita remover uma pessoa do ônibus.
■ um método que permita trocar o motorista do ônibus.
b. Crie um programa que permita testar as Classes acima.

Exercício 3

a. Crie as classes abaixo:
● Uma classe que represente um banco. Crie atributos e métodos para representar
esta classe.
● Uma classe que represente uma conta. Crie atributos e métodos para representar
esta classe. Além disso, crie uma forma para relacionar as contas criadas ao banco.
○ A classe conta deve conter obrigatoriamente:
■ atributos da conta do cliente, sua data de criação e o saldo da conta.
■ um método ou construtor que permita criar uma nova conta.

■ um método que permita sacar.
■ um método que permita depositar.
■ um método que permita verificar o saldo atual.

● Uma classe que represente um cliente. Crie atributos e métodos para representar
esta classe. Além disso, crie uma forma para relacionar o cliente à conta criada.
○ A classe cliente deve conter obrigatoriamente:
■ atributos do código do cliente, nome, cpf e endereço.
■ um método ou construtor que permita criar um novo cliente.
■ um método que permita imprimir os valores da conta do cliente.

b. Crie um programa que permita testar as Classes acima.
c. Altere o programa acima permitindo que um cliente possa transferir dinheiro
para conta de outro cliente.
 */

