package com.company;

import java.util.ArrayList;
import java.util.List;

public class Escola {
    public String Nome;
    public String Endereco;
    public String cnpj;
    public String razaoSocial;
    public List<Aluno> alunos = new ArrayList<>();

    public Escola(String cnpj, String Nome, String Endereco) {
        this.cnpj = cnpj;
        this.Nome = Nome;
        this.Endereco = Endereco;
        alunos = new ArrayList<>();
    }

}
