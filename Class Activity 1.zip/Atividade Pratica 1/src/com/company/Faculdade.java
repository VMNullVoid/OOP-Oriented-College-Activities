package com.company;

import java.util.ArrayList;
import java.util.List;

public class Faculdade {
    //abaixo o construtor da classe!
public String Nome;
public String Endereco;
public String cnpj;
public String notaMec;
public List<Aluno> alunos = new ArrayList<>();
   //abaixo o public da classe, pra torná-la acessível!
    public Faculdade(String cnpj, String Nome, String Endereco) {
        this.cnpj = cnpj;
        this.Nome = Nome;
        this.Endereco = Endereco;
    }
       public void AddAluno(Aluno aluno){
           this.alunos.add(aluno);
        }

}
