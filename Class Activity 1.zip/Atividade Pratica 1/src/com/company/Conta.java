package com.company;

import java.util.Scanner;

public class Conta {
    public String Numero_conta;
    public double saldo;
    public int tipo;
    public String data;
    public Cliente cliente;

    public Conta(String Numero_conta, int tipo, String data){
        this.Numero_conta = Numero_conta;
        this.data = data;
        this.tipo = tipo;
        this.saldo = 0;
    }
    //sacar
    public void SacarValor(double valor){
        if(valor > 0 && valor >= this.saldo){
            this.saldo -= valor;
        }else{
            System.out.println("Operação inválida! saldo insuficiente.\nSeu saldo atual é: " + saldo);
        }
    }
    public void Depositar(double valor){
        if(valor >= 0){
            this.saldo += valor;
        }else{
            System.out.println("Operação inválida! Não é possível adicionar valores negativos nesta operação. ");
        }

    }
    public void VerificarSaldo() {
        System.out.println("Saldo atual: " + saldo);
    }
    public void Transferir(double valor, Conta conta){
        this.SacarValor(valor);
        conta.Depositar(valor);
    }
    //depositar
    //impsaldo
}

