package com.company;

import java.util.ArrayList;
import java.util.List;

public class Onibus
{
    public String motorista;
    public double Quilometragem;
    public int qtdePessoas;

    public Onibus(int qtdePessoas)
    {
      this.qtdePessoas = qtdePessoas;
    }

    public boolean  getQuilometragem(double quilometragem)
    {
        if (quilometragem > 200)
        {
            System.out.println("O veículo não pode rodar! ");
          return false;
        } else System.out.println("Veículo capacitado. ");
        return true;
    }
    public void AddPessoas(int qtdePessoas){
        if (this.qtdePessoas + qtdePessoas <= 60){
         this.qtdePessoas = this.qtdePessoas + qtdePessoas;
        } else{
            System.out.println("O ônibus atingiu a capacidade máxima de pessoas! ");
        }
    }
    public void removeUmaPessoa(){
        if(qtdePessoas > 0){
            this.qtdePessoas--;
        } else{
            System.out.println("Ônibus sem passageiros! ");
        }
    }
    public void changeMotorista(String Motorista){
      this.motorista = Motorista;
    }
}
