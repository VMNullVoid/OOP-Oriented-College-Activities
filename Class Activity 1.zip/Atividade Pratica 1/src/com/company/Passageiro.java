package com.company;

public class Passageiro {

}
